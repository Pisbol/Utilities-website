</main>
<footer>
    <div class="foot-container">
        <p>&copy; <?php echo date('Y'); ?> Utilities by Ma. Gellena Ricci S. Negros.</p>
    </div>
</footer>
</body>
</html>
